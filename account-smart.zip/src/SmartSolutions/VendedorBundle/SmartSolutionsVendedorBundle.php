<?php

namespace SmartSolutions\VendedorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SmartSolutionsVendedorBundle extends Bundle
{
}

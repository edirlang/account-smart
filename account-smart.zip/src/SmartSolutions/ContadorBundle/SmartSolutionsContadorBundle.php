<?php

namespace SmartSolutions\ContadorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SmartSolutionsContadorBundle extends Bundle
{
}

<?php

namespace SmartSolutions\AdmistradorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SmartSolutionsAdmistradorBundle extends Bundle
{
}

<?php

namespace SmartSolutions\GerenteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SmartSolutionsGerenteBundle extends Bundle
{
}

<?php

namespace SmartSolutions\HomeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SmartSolutionsHomeBundle extends Bundle
{
}

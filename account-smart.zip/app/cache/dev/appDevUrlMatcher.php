<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ($pathinfo === '/_profiler/purge') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            if (0 === strpos($pathinfo, '/_configurator')) {
                // _configurator_home
                if (rtrim($pathinfo, '/') === '/_configurator') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_configurator_home');
                    }

                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::checkAction',  '_route' => '_configurator_home',);
                }

                // _configurator_step
                if (0 === strpos($pathinfo, '/_configurator/step') && preg_match('#^/_configurator/step/(?P<index>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_configurator_step')), array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::stepAction',));
                }

                // _configurator_final
                if ($pathinfo === '/_configurator/final') {
                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::finalAction',  '_route' => '_configurator_final',);
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/home')) {
            // smart_solutions_vendedor_homepage
            if ($pathinfo === '/homeVendedor') {
                return array (  '_controller' => 'SmartSolutions\\VendedorBundle\\Controller\\DefaultController::indexAction',  '_route' => 'smart_solutions_vendedor_homepage',);
            }

            // smart_solutions_gerente_homepage
            if ($pathinfo === '/homeGerente') {
                return array (  '_controller' => 'SmartSolutions\\GerenteBundle\\Controller\\DefaultController::indexAction',  '_route' => 'smart_solutions_gerente_homepage',);
            }

        }

        if (0 === strpos($pathinfo, '/cuentastransacion')) {
            // cuentastransacion
            if (rtrim($pathinfo, '/') === '/cuentastransacion') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'cuentastransacion');
                }

                return array (  '_controller' => 'SmartSolutions\\ContadorBundle\\Controller\\CuentasTransacionController::indexAction',  '_route' => 'cuentastransacion',);
            }

            // cuentastransacion_show
            if (preg_match('#^/cuentastransacion/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cuentastransacion_show')), array (  '_controller' => 'SmartSolutions\\ContadorBundle\\Controller\\CuentasTransacionController::showAction',));
            }

            // cuentastransacion_new
            if ($pathinfo === '/cuentastransacion/new') {
                return array (  '_controller' => 'SmartSolutions\\ContadorBundle\\Controller\\CuentasTransacionController::newAction',  '_route' => 'cuentastransacion_new',);
            }

            // cuentastransacion_create
            if ($pathinfo === '/cuentastransacion/create') {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_cuentastransacion_create;
                }

                return array (  '_controller' => 'SmartSolutions\\ContadorBundle\\Controller\\CuentasTransacionController::createAction',  '_route' => 'cuentastransacion_create',);
            }
            not_cuentastransacion_create:

            // cuentastransacion_edit
            if (preg_match('#^/cuentastransacion/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cuentastransacion_edit')), array (  '_controller' => 'SmartSolutions\\ContadorBundle\\Controller\\CuentasTransacionController::editAction',));
            }

            // cuentastransacion_update
            if (preg_match('#^/cuentastransacion/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                    $allow = array_merge($allow, array('POST', 'PUT'));
                    goto not_cuentastransacion_update;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cuentastransacion_update')), array (  '_controller' => 'SmartSolutions\\ContadorBundle\\Controller\\CuentasTransacionController::updateAction',));
            }
            not_cuentastransacion_update:

            // cuentastransacion_delete
            if (preg_match('#^/cuentastransacion/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                    $allow = array_merge($allow, array('POST', 'DELETE'));
                    goto not_cuentastransacion_delete;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'cuentastransacion_delete')), array (  '_controller' => 'SmartSolutions\\ContadorBundle\\Controller\\CuentasTransacionController::deleteAction',));
            }
            not_cuentastransacion_delete:

        }

        // smart_solutions_contador_homepage
        if ($pathinfo === '/homeContador') {
            return array (  '_controller' => 'SmartSolutions\\ContadorBundle\\Controller\\DefaultController::indexAction',  '_route' => 'smart_solutions_contador_homepage',);
        }

        // smart_solutions_home_homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'smart_solutions_home_homepage');
            }

            return array (  '_controller' => 'SmartSolutions\\HomeBundle\\Controller\\DefaultController::indexAction',  '_route' => 'smart_solutions_home_homepage',);
        }

        if (0 === strpos($pathinfo, '/admin')) {
            if (0 === strpos($pathinfo, '/admin/p')) {
                if (0 === strpos($pathinfo, '/admin/proveedor')) {
                    // proveedor
                    if (rtrim($pathinfo, '/') === '/admin/proveedor') {
                        if (substr($pathinfo, -1) !== '/') {
                            return $this->redirect($pathinfo.'/', 'proveedor');
                        }

                        return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ProveedorController::indexAction',  '_route' => 'proveedor',);
                    }

                    // proveedor_show
                    if (preg_match('#^/admin/proveedor/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'proveedor_show')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ProveedorController::showAction',));
                    }

                    // proveedor_new
                    if ($pathinfo === '/admin/proveedor/new') {
                        return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ProveedorController::newAction',  '_route' => 'proveedor_new',);
                    }

                    // proveedor_create
                    if ($pathinfo === '/admin/proveedor/create') {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_proveedor_create;
                        }

                        return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ProveedorController::createAction',  '_route' => 'proveedor_create',);
                    }
                    not_proveedor_create:

                    // proveedor_edit
                    if (preg_match('#^/admin/proveedor/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'proveedor_edit')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ProveedorController::editAction',));
                    }

                    // proveedor_update
                    if (preg_match('#^/admin/proveedor/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                            $allow = array_merge($allow, array('POST', 'PUT'));
                            goto not_proveedor_update;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'proveedor_update')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ProveedorController::updateAction',));
                    }
                    not_proveedor_update:

                    // proveedor_delete
                    if (preg_match('#^/admin/proveedor/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                            $allow = array_merge($allow, array('POST', 'DELETE'));
                            goto not_proveedor_delete;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'proveedor_delete')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ProveedorController::deleteAction',));
                    }
                    not_proveedor_delete:

                    // proveedor_state
                    if (preg_match('#^/admin/proveedor/(?P<id>[^/]++)/(?P<state>[^/]++)/state$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'proveedor_state')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ProveedorController::updateStateAction',));
                    }

                }

                if (0 === strpos($pathinfo, '/admin/pension')) {
                    // pension
                    if (rtrim($pathinfo, '/') === '/admin/pension') {
                        if (substr($pathinfo, -1) !== '/') {
                            return $this->redirect($pathinfo.'/', 'pension');
                        }

                        return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\PensionController::indexAction',  '_route' => 'pension',);
                    }

                    // pension_show
                    if (preg_match('#^/admin/pension/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'pension_show')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\PensionController::showAction',));
                    }

                    // pension_new
                    if ($pathinfo === '/admin/pension/new') {
                        return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\PensionController::newAction',  '_route' => 'pension_new',);
                    }

                    // pension_create
                    if ($pathinfo === '/admin/pension/create') {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_pension_create;
                        }

                        return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\PensionController::createAction',  '_route' => 'pension_create',);
                    }
                    not_pension_create:

                    // pension_edit
                    if (preg_match('#^/admin/pension/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'pension_edit')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\PensionController::editAction',));
                    }

                    // pension_update
                    if (preg_match('#^/admin/pension/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                            $allow = array_merge($allow, array('POST', 'PUT'));
                            goto not_pension_update;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'pension_update')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\PensionController::updateAction',));
                    }
                    not_pension_update:

                    // pension_delete
                    if (preg_match('#^/admin/pension/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                            $allow = array_merge($allow, array('POST', 'DELETE'));
                            goto not_pension_delete;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'pension_delete')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\PensionController::deleteAction',));
                    }
                    not_pension_delete:

                }

            }

            if (0 === strpos($pathinfo, '/admin/eps')) {
                // eps
                if (rtrim($pathinfo, '/') === '/admin/eps') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'eps');
                    }

                    return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\EpsController::indexAction',  '_route' => 'eps',);
                }

                // eps_show
                if (preg_match('#^/admin/eps/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'eps_show')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\EpsController::showAction',));
                }

                // eps_new
                if ($pathinfo === '/admin/eps/new') {
                    return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\EpsController::newAction',  '_route' => 'eps_new',);
                }

                // eps_create
                if ($pathinfo === '/admin/eps/create') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_eps_create;
                    }

                    return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\EpsController::createAction',  '_route' => 'eps_create',);
                }
                not_eps_create:

                // eps_edit
                if (preg_match('#^/admin/eps/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'eps_edit')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\EpsController::editAction',));
                }

                // eps_update
                if (preg_match('#^/admin/eps/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                        $allow = array_merge($allow, array('POST', 'PUT'));
                        goto not_eps_update;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'eps_update')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\EpsController::updateAction',));
                }
                not_eps_update:

                // eps_delete
                if (preg_match('#^/admin/eps/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                        $allow = array_merge($allow, array('POST', 'DELETE'));
                        goto not_eps_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'eps_delete')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\EpsController::deleteAction',));
                }
                not_eps_delete:

            }

            if (0 === strpos($pathinfo, '/admin/clientes')) {
                // clientes
                if (rtrim($pathinfo, '/') === '/admin/clientes') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'clientes');
                    }

                    return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ClientesController::indexAction',  '_route' => 'clientes',);
                }

                // clientes_show
                if (preg_match('#^/admin/clientes/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'clientes_show')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ClientesController::showAction',));
                }

                // clientes_new
                if ($pathinfo === '/admin/clientes/new') {
                    return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ClientesController::newAction',  '_route' => 'clientes_new',);
                }

                // clientes_create
                if ($pathinfo === '/admin/clientes/create') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_clientes_create;
                    }

                    return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ClientesController::createAction',  '_route' => 'clientes_create',);
                }
                not_clientes_create:

                // clientes_edit
                if (preg_match('#^/admin/clientes/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'clientes_edit')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ClientesController::editAction',));
                }

                // clientes_update
                if (preg_match('#^/admin/clientes/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                        $allow = array_merge($allow, array('POST', 'PUT'));
                        goto not_clientes_update;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'clientes_update')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ClientesController::updateAction',));
                }
                not_clientes_update:

                // clientes_delete
                if (preg_match('#^/admin/clientes/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                        $allow = array_merge($allow, array('POST', 'DELETE'));
                        goto not_clientes_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'clientes_delete')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\ClientesController::deleteAction',));
                }
                not_clientes_delete:

            }

            if (0 === strpos($pathinfo, '/admin/users')) {
                // users
                if (rtrim($pathinfo, '/') === '/admin/users') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'users');
                    }

                    return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\UsersController::indexAction',  '_route' => 'users',);
                }

                // users_show
                if (preg_match('#^/admin/users/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'users_show')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\UsersController::showAction',));
                }

                // users_new
                if ($pathinfo === '/admin/users/new') {
                    return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\UsersController::newAction',  '_route' => 'users_new',);
                }

                // users_create
                if ($pathinfo === '/admin/users/create') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_users_create;
                    }

                    return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\UsersController::createAction',  '_route' => 'users_create',);
                }
                not_users_create:

                // users_edit
                if (preg_match('#^/admin/users/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'users_edit')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\UsersController::editAction',));
                }

                // users_update
                if (preg_match('#^/admin/users/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                        $allow = array_merge($allow, array('POST', 'PUT'));
                        goto not_users_update;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'users_update')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\UsersController::updateAction',));
                }
                not_users_update:

                // users_delete
                if (preg_match('#^/admin/users/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                        $allow = array_merge($allow, array('POST', 'DELETE'));
                        goto not_users_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'users_delete')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\UsersController::deleteAction',));
                }
                not_users_delete:

                // users_state
                if (preg_match('#^/admin/users/(?P<id>[^/]++)/(?P<state>[^/]++)/state$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'users_state')), array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\UsersController::updateStateAction',));
                }

            }

            // smart_solutions_admistrador_homepage
            if ($pathinfo === '/admin/homeAdmin') {
                return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\DefaultController::indexAction',  '_route' => 'smart_solutions_admistrador_homepage',);
            }

        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        if (0 === strpos($pathinfo, '/log')) {
            // logout
            if ($pathinfo === '/logout') {
                return array('_route' => 'logout');
            }

            if (0 === strpos($pathinfo, '/login')) {
                // login
                if ($pathinfo === '/login') {
                    return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\DefaultController::loginAction',  '_route' => 'login',);
                }

                // login_check
                if ($pathinfo === '/login_check') {
                    return array (  '_controller' => 'SmartSolutions\\AdmistradorBundle\\Controller\\DefaultController::loginCheckAction',  '_route' => 'login_check',);
                }

            }

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
